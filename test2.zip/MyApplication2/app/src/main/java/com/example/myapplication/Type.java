package com.example.myapplication;

public class Type {
    String CountryType;
}
