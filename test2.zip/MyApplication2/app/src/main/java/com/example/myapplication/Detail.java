package com.example.myapplication;

public class Detail {
    int id;
    String title;
    String singer;
    String melodizer;
    String lyricist;
    String genre;
}
