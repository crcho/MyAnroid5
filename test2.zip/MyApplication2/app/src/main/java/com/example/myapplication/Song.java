package com.example.myapplication;

public class Song {
    int id;
    int rank;
    String title;
    String singer;
    String imageUrl;
}
